'use client'

import { useState, useRef, useCallback } from 'react'

type ScrapeResult = {
  domain: string
  emails: string[]
  status: 'pending' | 'running' | 'done' | 'error'
  error?: string
}

export default function Home() {
  const [apiKey, setApiKey] = useState('')
  const [isConfigured, setIsConfigured] = useState(false)
  const [mode, setMode] = useState<'bulk' | 'crawl'>('bulk')
  const [bulkUrls, setBulkUrls] = useState('')
  const [crawlUrl, setCrawlUrl] = useState('')
  const [crawlDepth, setCrawlDepth] = useState(2)
  const [checkSubpages, setCheckSubpages] = useState(true)
  const [maxSubpages, setMaxSubpages] = useState(10)
  const [running, setRunning] = useState(false)
  const [status, setStatus] = useState('')
  const [progress, setProgress] = useState('')
  const [results, setResults] = useState<ScrapeResult[]>([])
  const [error, setError] = useState('')
  const pollRef = useRef<NodeJS.Timeout | null>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const configure = () => {
    if (!apiKey.trim()) { setError('Ange Apify API-token'); return }
    setIsConfigured(true)
    setError('')
  }

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return
    const reader = new FileReader()
    reader.onload = (ev) => {
      const text = ev.target?.result as string
      const urls = text.split('\n')
        .map(line => line.split(',')[0].trim())
        .filter(u => u && !u.toLowerCase().startsWith('url') && !u.toLowerCase().startsWith('http') ? false : true)
        .filter(u => u.includes('.'))
      setBulkUrls(prev => prev ? prev + '\n' + urls.join('\n') : urls.join('\n'))
    }
    reader.readAsText(file)
  }

  const normalizeUrl = (u: string) => {
    u = u.trim()
    if (!u) return ''
    if (!u.startsWith('http://') && !u.startsWith('https://')) u = 'https://' + u
    return u
  }

  const startScrape = async () => {
    setError('')
    setResults([])
    setRunning(true)
    setProgress('')

    let urls: string[] = []
    if (mode === 'crawl') {
      const u = normalizeUrl(crawlUrl)
      if (!u) { setError('Ange en URL'); setRunning(false); return }
      urls = [u]
    } else {
      urls = bulkUrls.split('\n').map(normalizeUrl).filter(u => u)
      if (urls.length === 0) { setError('Klistra in minst en URL'); setRunning(false); return }
    }

    setStatus(`Startar scraping av ${urls.length} ${urls.length === 1 ? 'sajt' : 'sajter'}...`)

    try {
      const res = await fetch('/api/scrape', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          apiKey,
          urls,
          mode,
          crawlDepth: mode === 'crawl' ? crawlDepth : (checkSubpages ? 1 : 0),
          maxRequests: mode === 'crawl' ? 50 : (checkSubpages ? maxSubpages : 1),
        }),
      })

      if (!res.ok) {
        const data = await res.json()
        throw new Error(data.error || 'Något gick fel')
      }

      const { runId, datasetId } = await res.json()
      setStatus('Scraping pågår...')

      // Poll for status
      pollRef.current = setInterval(async () => {
        try {
          const statusRes = await fetch(`/api/status?runId=${runId}&apiKey=${encodeURIComponent(apiKey)}`)
          const statusData = await statusRes.json()

          if (statusData.stats) {
            setProgress(`${statusData.stats.requestsFinished || 0} sidor scrapade, ${statusData.stats.requestsFailed || 0} misslyckade`)
          }

          if (statusData.status === 'SUCCEEDED') {
            if (pollRef.current) clearInterval(pollRef.current)
            setStatus('Hämtar resultat...')

            const itemsRes = await fetch(`/api/status?datasetId=${statusData.datasetId}&apiKey=${encodeURIComponent(apiKey)}&getItems=true`)
            const items = await itemsRes.json()

            const emailMap = new Map<string, Set<string>>()
            items.forEach((item: any) => {
              const url = item.url || item.startUrl || 'unknown'
              let domain: string
              try { domain = new URL(url).hostname } catch { domain = url }
              if (!emailMap.has(domain)) emailMap.set(domain, new Set())
              ;(item.emails || []).forEach((e: string) => emailMap.get(domain)!.add(e.toLowerCase()))
            })

            const formatted: ScrapeResult[] = []
            emailMap.forEach((emails, domain) => {
              formatted.push({ domain, emails: [...emails], status: 'done' })
            })

            setResults(formatted)
            const total = formatted.reduce((a, r) => a + r.emails.length, 0)
            setStatus(`Klart! ${total} e-postadresser från ${formatted.length} domäner.`)
            setRunning(false)
          } else if (['FAILED', 'ABORTED', 'TIMED-OUT'].includes(statusData.status)) {
            if (pollRef.current) clearInterval(pollRef.current)
            setError(`Körningen ${statusData.status.toLowerCase()}`)
            setStatus('')
            setRunning(false)
          }
        } catch (e: any) {
          if (pollRef.current) clearInterval(pollRef.current)
          setError('Polling error: ' + e.message)
          setRunning(false)
        }
      }, 4000)

    } catch (e: any) {
      setError(e.message)
      setStatus('')
      setRunning(false)
    }
  }

  const stopScrape = () => {
    if (pollRef.current) clearInterval(pollRef.current)
    setRunning(false)
    setStatus('Stoppad.')
  }

  const exportCSV = () => {
    let csv = 'Domän,E-postadresser\n'
    results.forEach(r => {
      csv += `"${r.domain}","${r.emails.join(', ')}"\n`
    })
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' })
    const link = document.createElement('a')
    link.href = URL.createObjectURL(blob)
    link.download = 'emails_' + new Date().toISOString().slice(0, 10) + '.csv'
    link.click()
  }

  const urlCount = bulkUrls.split('\n').filter(u => u.trim()).length
  const totalEmails = results.reduce((a, r) => a + r.emails.length, 0)

  return (
    <>
      <style jsx global>{`
        * { margin: 0; padding: 0; box-sizing: border-box; }
        :root {
          --bg: #08080c;
          --surface: #111118;
          --surface-2: #1a1a24;
          --border: #252530;
          --accent: #22d3a7;
          --accent-glow: rgba(34, 211, 167, 0.15);
          --accent-dim: rgba(34, 211, 167, 0.08);
          --text: #e8e8ef;
          --text-dim: #65657a;
          --red: #f43f5e;
          --red-dim: rgba(244, 63, 94, 0.1);
          --mono: 'Space Mono', monospace;
          --sans: 'DM Sans', sans-serif;
        }
        body { font-family: var(--sans); background: var(--bg); color: var(--text); min-height: 100vh; }
        
        .container { max-width: 800px; margin: 0 auto; padding: 32px 20px; }
        
        .logo { display: flex; align-items: center; gap: 10px; margin-bottom: 32px; }
        .logo-icon { width: 36px; height: 36px; background: var(--accent); border-radius: 8px; display: flex; align-items: center; justify-content: center; font-size: 18px; }
        .logo h1 { font-family: var(--mono); font-size: 20px; font-weight: 700; letter-spacing: -0.5px; }
        .logo .version { font-family: var(--mono); font-size: 11px; color: var(--accent); background: var(--accent-dim); padding: 2px 8px; border-radius: 4px; margin-left: 8px; }
        
        .card { background: var(--surface); border: 1px solid var(--border); border-radius: 12px; padding: 24px; margin-bottom: 16px; }
        
        .label { font-family: var(--mono); font-size: 11px; text-transform: uppercase; letter-spacing: 1.5px; color: var(--text-dim); margin-bottom: 8px; display: block; }
        
        input[type="text"], input[type="password"], input[type="number"], textarea {
          width: 100%; background: var(--bg); border: 1px solid var(--border);
          border-radius: 8px; padding: 12px 14px; color: var(--text);
          font-family: var(--mono); font-size: 13px; outline: none;
          transition: border-color 0.2s;
        }
        input:focus, textarea:focus { border-color: var(--accent); }
        textarea { min-height: 180px; resize: vertical; line-height: 1.6; }
        
        .btn {
          border-radius: 8px; padding: 11px 22px; font-family: var(--sans);
          font-size: 14px; font-weight: 600; cursor: pointer; border: none;
          transition: all 0.15s; display: inline-flex; align-items: center; gap: 6px;
        }
        .btn-primary { background: var(--accent); color: var(--bg); }
        .btn-primary:hover { opacity: 0.9; transform: translateY(-1px); }
        .btn-secondary { background: transparent; color: var(--text); border: 1px solid var(--border); }
        .btn-secondary:hover { border-color: var(--text-dim); }
        .btn-danger { background: transparent; color: var(--red); border: 1px solid rgba(244,63,94,0.3); }
        .btn-sm { padding: 7px 14px; font-size: 12px; }
        
        .tabs { display: flex; gap: 4px; margin-bottom: 16px; background: var(--surface); border-radius: 10px; padding: 4px; border: 1px solid var(--border); }
        .tab {
          flex: 1; text-align: center; padding: 10px; font-family: var(--mono);
          font-size: 12px; font-weight: 700; cursor: pointer; border-radius: 7px;
          text-transform: uppercase; letter-spacing: 0.5px; transition: all 0.15s;
          color: var(--text-dim); background: transparent; border: none;
        }
        .tab.active { background: var(--accent-dim); color: var(--accent); }
        
        .toggle-row { display: flex; align-items: center; gap: 14px; margin-top: 16px; }
        .toggle-row label { display: flex; align-items: center; gap: 6px; font-size: 13px; cursor: pointer; }
        .toggle-row input[type="checkbox"] { accent-color: var(--accent); }
        .toggle-row input[type="number"] { width: 65px; padding: 6px 10px; }
        
        .status-box { border-color: rgba(34,211,167,0.2); background: var(--accent-dim); }
        .status-box .main { color: var(--accent); font-size: 14px; font-weight: 500; }
        .status-box .sub { color: var(--text-dim); font-size: 12px; margin-top: 4px; font-family: var(--mono); }
        
        .error-box { border-color: rgba(244,63,94,0.2); background: var(--red-dim); }
        .error-box p { color: var(--red); font-size: 13px; }
        
        .results-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px; }
        .results-count { font-family: var(--mono); font-size: 13px; color: var(--accent); }
        
        .results-table { width: 100%; border-collapse: collapse; }
        .results-table th {
          text-align: left; padding: 10px 12px; font-family: var(--mono);
          font-size: 11px; text-transform: uppercase; letter-spacing: 1px;
          color: var(--text-dim); border-bottom: 1px solid var(--border);
        }
        .results-table td {
          padding: 10px 12px; border-bottom: 1px solid rgba(37,37,48,0.5);
          font-size: 13px; vertical-align: top;
        }
        .results-table .domain { color: var(--accent); font-family: var(--mono); font-size: 12px; white-space: nowrap; }
        .results-table .email-list { word-break: break-all; line-height: 1.6; }
        .results-table .no-email { color: var(--text-dim); font-style: italic; }
        .results-scroll { max-height: 500px; overflow-y: auto; }
        
        .actions { display: flex; gap: 8px; margin-bottom: 16px; flex-wrap: wrap; }
        
        .url-count { font-family: var(--mono); font-size: 11px; color: var(--text-dim); margin-top: 6px; }
        
        .upload-btn { display: inline-flex; align-items: center; gap: 6px; cursor: pointer; }
        .upload-btn input { display: none; }
        
        .pulse { animation: pulse 2s infinite; }
        @keyframes pulse { 0%, 100% { opacity: 1; } 50% { opacity: 0.5; } }
        
        .stats-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 12px; margin-bottom: 16px; }
        .stat-card { background: var(--surface-2); border-radius: 8px; padding: 14px; text-align: center; }
        .stat-card .value { font-family: var(--mono); font-size: 24px; font-weight: 700; color: var(--accent); }
        .stat-card .label { font-size: 11px; color: var(--text-dim); margin-top: 4px; text-transform: uppercase; letter-spacing: 1px; }
        
        .divider { height: 1px; background: var(--border); margin: 24px 0; }
      `}</style>

      <div className="container">
        {!isConfigured ? (
          <>
            <div className="logo">
              <div className="logo-icon">⚡</div>
              <h1>Scraper</h1>
              <span className="version">v1.0</span>
            </div>

            <div className="card">
              <p style={{ color: 'var(--text-dim)', fontSize: 14, marginBottom: 20, lineHeight: 1.6 }}>
                Extrahera e-postadresser från valfri webbplats. Klistra in URLer eller ladda upp en CSV — appen crawlar sajterna via Apify och levererar en ren lista.
              </p>
              <label className="label">Apify API Token</label>
              <input
                type="password"
                value={apiKey}
                onChange={e => setApiKey(e.target.value)}
                placeholder="apify_api_xxxxxxxxxxxxxxxx"
                onKeyDown={e => e.key === 'Enter' && configure()}
              />
              <p style={{ fontSize: 11, color: 'var(--text-dim)', marginTop: 8 }}>
                Hämta din token på <a href="https://console.apify.com/account/integrations" target="_blank" style={{ color: 'var(--accent)' }}>console.apify.com</a>
              </p>
            </div>

            {error && <div className="card error-box"><p>{error}</p></div>}

            <button className="btn btn-primary" onClick={configure}>
              Kom igång →
            </button>
          </>
        ) : (
          <>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 24 }}>
              <div className="logo">
                <div className="logo-icon">⚡</div>
                <h1>Scraper</h1>
                <span className="version">v1.0</span>
              </div>
              <button className="btn btn-secondary btn-sm" onClick={() => { setIsConfigured(false); setResults([]) }}>
                Ändra nyckel
              </button>
            </div>

            {/* Tabs */}
            <div className="tabs">
              <button className={`tab ${mode === 'bulk' ? 'active' : ''}`} onClick={() => setMode('bulk')}>
                Bulk URLer
              </button>
              <button className={`tab ${mode === 'crawl' ? 'active' : ''}`} onClick={() => setMode('crawl')}>
                Crawl sajt
              </button>
            </div>

            {/* Input */}
            <div className="card">
              {mode === 'crawl' ? (
                <>
                  <label className="label">Start-URL</label>
                  <input
                    type="text"
                    value={crawlUrl}
                    onChange={e => setCrawlUrl(e.target.value)}
                    placeholder="https://example.com"
                  />
                  <div style={{ marginTop: 12 }}>
                    <label className="label">Crawl-djup</label>
                    <input
                      type="number" min={1} max={10}
                      value={crawlDepth}
                      onChange={e => setCrawlDepth(parseInt(e.target.value) || 1)}
                      style={{ width: 80 }}
                    />
                  </div>
                </>
              ) : (
                <>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 }}>
                    <label className="label" style={{ margin: 0 }}>URLer (en per rad)</label>
                    <label className="btn btn-secondary btn-sm upload-btn">
                      📎 Ladda upp CSV
                      <input type="file" accept=".csv,.txt" ref={fileInputRef} onChange={handleFileUpload} />
                    </label>
                  </div>
                  <textarea
                    value={bulkUrls}
                    onChange={e => setBulkUrls(e.target.value)}
                    placeholder={"example.com\nfirma1.se\nfirma2.se\nhttps://firma3.se"}
                  />
                  <p className="url-count">{urlCount} {urlCount === 1 ? 'URL' : 'URLer'}</p>
                </>
              )}

              <div className="toggle-row">
                <label>
                  <input type="checkbox" checked={checkSubpages} onChange={e => setCheckSubpages(e.target.checked)} />
                  Kolla undersidor
                </label>
                {checkSubpages && (
                  <label>
                    Max:
                    <input
                      type="number" min={1} max={100}
                      value={maxSubpages}
                      onChange={e => setMaxSubpages(parseInt(e.target.value) || 5)}
                    />
                  </label>
                )}
              </div>
            </div>

            {/* Actions */}
            <div className="actions">
              {!running ? (
                <button className="btn btn-primary" onClick={startScrape}>
                  ▶ Starta scraping
                </button>
              ) : (
                <button className="btn btn-danger" onClick={stopScrape}>
                  ■ Stoppa
                </button>
              )}
              {results.length > 0 && (
                <button className="btn btn-secondary" onClick={exportCSV}>
                  ↓ Exportera CSV
                </button>
              )}
            </div>

            {/* Status */}
            {(status || progress) && (
              <div className="card status-box">
                <p className={`main ${running ? 'pulse' : ''}`}>{running ? '⏳ ' : '✅ '}{status}</p>
                {progress && <p className="sub">{progress}</p>}
              </div>
            )}

            {/* Error */}
            {error && (
              <div className="card error-box">
                <p>{error}</p>
              </div>
            )}

            {/* Results */}
            {results.length > 0 && (
              <>
                <div className="stats-grid">
                  <div className="stat-card">
                    <div className="value">{results.length}</div>
                    <div className="label">Domäner</div>
                  </div>
                  <div className="stat-card">
                    <div className="value">{totalEmails}</div>
                    <div className="label">E-postadresser</div>
                  </div>
                  <div className="stat-card">
                    <div className="value">{results.filter(r => r.emails.length > 0).length}</div>
                    <div className="label">Med träff</div>
                  </div>
                </div>

                <div className="card">
                  <div className="results-scroll">
                    <table className="results-table">
                      <thead>
                        <tr>
                          <th>Domän</th>
                          <th>E-postadresser</th>
                        </tr>
                      </thead>
                      <tbody>
                        {results.map((r, i) => (
                          <tr key={i}>
                            <td className="domain">{r.domain}</td>
                            <td>
                              {r.emails.length > 0 ? (
                                <span className="email-list">{r.emails.join(', ')}</span>
                              ) : (
                                <span className="no-email">Ingen hittad</span>
                              )}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </>
            )}
          </>
        )}
      </div>
    </>
  )
}
