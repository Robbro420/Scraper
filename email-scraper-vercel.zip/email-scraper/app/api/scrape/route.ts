import { NextRequest, NextResponse } from 'next/server'

const ACTOR_ID = 'lukaskrivka/contact-info-scraper'

export async function POST(req: NextRequest) {
  try {
    const { apiKey, urls, mode, crawlDepth, maxRequests } = await req.json()

    if (!apiKey) {
      return NextResponse.json({ error: 'API-nyckel saknas' }, { status: 400 })
    }

    if (!urls || urls.length === 0) {
      return NextResponse.json({ error: 'Inga URLer angivna' }, { status: 400 })
    }

    const input = {
      startUrls: urls.map((url: string) => ({ url })),
      maxDepth: crawlDepth || 1,
      maxRequestsPerStartUrl: maxRequests || 10,
      sameDomain: true,
    }

    const runRes = await fetch(
      `https://api.apify.com/v2/acts/${ACTOR_ID}/runs?token=${apiKey}`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(input),
      }
    )

    if (!runRes.ok) {
      const errData = await runRes.json().catch(() => ({}))
      return NextResponse.json(
        { error: errData.error?.message || `Apify error: ${runRes.status}` },
        { status: runRes.status }
      )
    }

    const runData = await runRes.json()
    
    return NextResponse.json({
      runId: runData.data.id,
      datasetId: runData.data.defaultDatasetId,
    })
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 })
  }
}
