import { NextRequest, NextResponse } from 'next/server'

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url)
  const apiKey = searchParams.get('apiKey')
  const runId = searchParams.get('runId')
  const datasetId = searchParams.get('datasetId')
  const getItems = searchParams.get('getItems')

  if (!apiKey) {
    return NextResponse.json({ error: 'API key missing' }, { status: 400 })
  }

  try {
    // If getItems=true, fetch dataset items
    if (getItems === 'true' && datasetId) {
      const itemsRes = await fetch(
        `https://api.apify.com/v2/datasets/${datasetId}/items?token=${apiKey}&limit=10000`
      )
      if (!itemsRes.ok) {
        return NextResponse.json({ error: 'Failed to fetch items' }, { status: 500 })
      }
      const items = await itemsRes.json()
      return NextResponse.json(items)
    }

    // Otherwise, check run status
    if (!runId) {
      return NextResponse.json({ error: 'runId missing' }, { status: 400 })
    }

    const statusRes = await fetch(
      `https://api.apify.com/v2/actor-runs/${runId}?token=${apiKey}`
    )

    if (!statusRes.ok) {
      return NextResponse.json({ error: 'Failed to fetch status' }, { status: 500 })
    }

    const statusData = await statusRes.json()

    return NextResponse.json({
      status: statusData.data.status,
      stats: statusData.data.stats,
      datasetId: statusData.data.defaultDatasetId,
    })
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 })
  }
}
