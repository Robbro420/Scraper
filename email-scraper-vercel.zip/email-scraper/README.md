# ⚡ Email Scraper

En Next.js-app som extraherar e-postadresser från webbplatser via Apify.

## Snabbstart

### 1. Klona och installera
```bash
git clone <ditt-repo>
cd email-scraper
npm install
```

### 2. Lägg till miljövariabler
Kopiera `.env.example` till `.env.local`:
```bash
cp .env.example .env.local
```
Fyll i din Apify API-token (valfritt — du kan också ange den i UI:t).

### 3. Kör lokalt
```bash
npm run dev
```
Öppna [http://localhost:3000](http://localhost:3000)

### 4. Deploya till Vercel
```bash
# Installera Vercel CLI om du inte har det
npm i -g vercel

# Deploya
vercel
```

Eller koppla ditt GitHub-repo till Vercel direkt via vercel.com/dashboard.

## Funktioner

- **Bulk-läge**: Klistra in hundratals URLer eller ladda upp en CSV
- **Crawl-läge**: Ange en start-URL och djup, appen följer alla länkar
- **Undersidor**: Toggle för att automatiskt kolla /kontakt, /om-oss osv.
- **CSV-export**: Ladda ner alla resultat som CSV
- **Realtidsprogress**: Se hur många sidor som scrapats

## Teknik

- Next.js 14 (App Router)
- Apify (contact-info-scraper actor)
- API-nyckeln skickas aldrig till klienten vid server-side calls
- Ingen databas behövs — allt körs stateless

## Kostnader

- Vercel Pro: din befintliga plan
- Apify: Free tier ($5/mån) räcker för ~1000 sidor/mån
- Uppgradera Apify vid behov ($49/mån för mer compute + proxies)
